import 'dart:typed_data';
import 'dart:async';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/material.dart';
import 'package:image/image.dart' as imglib;

class runningpage extends StatefulWidget {
  String? ph;
  String? dr_path;

  runningpage(this.ph, this.dr_path);

  @override
  State<runningpage> createState() => _runningpageState();
}

class _runningpageState extends State<runningpage> {
  dynamic div = 3;
  List<Image> im = [];

  List<Image> splitImage(List<int> input) {
    // convert image to image from image package
    imglib.Image? image = imglib.decodeImage(input);

    int x = 0, y = 0;
    int width = (image!.width / div).round();
    int height = (image.height / div).round();

    // split image to parts
    List<imglib.Image> parts = [];
    for (int i = 0; i < div; i++) {
      for (int j = 0; j < div; j++) {
        parts.add(imglib.copyCrop(image, x, y, width, height));
        x += width;
      }
      x = 0;
      y += height;
    }

    // convert image from image package to Image Widget to display
    List<Image> output = [];
    for (var img in parts) {
      //
      output.add(Image.memory(Uint8List.fromList(imglib.encodeJpg(img))));
    }

    return output;
  }

  Future<File> getImageFileFromAssets(String path) async {
    final byteData = await rootBundle.load('$path');
    DateTime datetime = DateTime.now();

    String setin =
        "${datetime.year.toString() + datetime.month.toString() + datetime.day.toString() + datetime.hour.toString() + datetime.minute.toString() + datetime.second.toString() + datetime.microsecond.toString()}";
    String imagepath = "${widget.dr_path}/${setin}.jpg";
    final file = File('$imagepath');
    await file.writeAsBytes(byteData.buffer
        .asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));

    return file;
  }

  declareimage() async {
    File f = await getImageFileFromAssets('myimage/${widget.ph}');
    List<int> imagelist = await f.readAsBytes();
    im = await splitImage(imagelist);
    print("f.path =  =${f.path}");
    print("im =  =${im}");
    im.shuffle();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    declareimage();
  }
  bool isselect = false;
  Color C=Colors.purpleAccent;
  List<Image> drim=[];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //todo mr000142indy
      appBar: AppBar(),
      body: Draggable(

        data: ,
        child: GridView.builder(
          itemCount: im.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              mainAxisSpacing: 5,
              crossAxisSpacing: 5,
              crossAxisCount: div),
          itemBuilder: (context, index) {
            return InkWell(
              onLongPress: () {

              },
              child: Container(
                child: im[index],
              ),
            );
          },
        ),
        feedback: DragTarget(
          onWillAccept: (data) {
            return true;
          },
          onAccept: (data) {
            print(data);
            setState(() {

            });
          },

          builder: (context, candidateData, rejectedData) {
            return Container(
              height: 100,
              width: 100,
              color: C,
            );
          },
        ),
      ),
    );
  }
} /*Container(width: 200,height: 200,color: Colors.amber,)*/
