import 'package:flutter/material.dart';
import 'splash.dart';

void main() {
  runApp(MaterialApp(
    home: splash(),
  ));
}
